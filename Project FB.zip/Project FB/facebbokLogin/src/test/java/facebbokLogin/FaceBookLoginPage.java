package facebbokLogin;

import static org.testng.Assert.assertEquals;

import java.io.*;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.opencsv.CSVWriter;

public class FaceBookLoginPage extends Utils {
	
	Utils ut = new Utils();
	String line = "";
	String splitBy = ",";
	String url = "https://www.facebook.com/";

	@Test
	public void Userlogin() throws IOException {

		FileReader filereader = new FileReader(System.getProperty("user.dir") + "\\src\\main\\java\\FBCredentials.csv");
		BufferedReader br = new BufferedReader(filereader);

		String headers = br.readLine();
		while ((line = br.readLine()) != null) // returns a Boolean value

		{

			String[] employee = line.split(splitBy); // use comma as separator

			System.out.println(
					"User Name = " + employee[0] + "Password =" + employee[1] + "Expected result =" + employee[2]);
			ut.getbrowser("Chrome");

			driver.get(url);
			WebElement userName = driver.findElement(By.name("email"));
			userName.sendKeys(employee[0]);
			WebElement password = driver.findElement(By.name("pass"));
			password.sendKeys(employee[1]);
			WebElement login = driver.findElement(By.name("login"));
			login.click();

			String title = driver.getTitle();
			System.out.println(title);
			if (title.equals("Facebook")) {
				Assert.assertEquals(employee[2], "Pass");

			} else {
				Assert.assertEquals(employee[2], "Fail");

			}

		}

	}

}
